import { 
  Controller, 
  Get, 
  Post, 
  Delete, 
  Body, 
  Param,
  UseInterceptors,
  UploadedFile,
  HttpCode,
  HttpStatus,
  BadRequestException
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import * as xlsx from 'xlsx';
import { LotteryService } from './lottery.service';

@Controller()
export class LotteryController {
  constructor(private readonly lotteryService: LotteryService) {}

  // ============ 参与人员管理 ============

  @Get('participants')
  getParticipants() {
    return {
      code: 200,
      msg: 'success',
      data: this.lotteryService.getParticipants()
    };
  }

  @Post('participants/upload')
  @HttpCode(HttpStatus.OK)
  @UseInterceptors(FileInterceptor('file'))
  async uploadParticipants(@UploadedFile() file: Express.Multer.File) {
    if (!file) {
      throw new BadRequestException('请选择要上传的文件');
    }

    let participants: Array<{ id: string; name: string; employeeId: string; department: string; hasWon: boolean }> = [];

    try {
      // 支持同时处理 buffer（H5）和 path（小程序）
      let workbook: xlsx.WorkBook;
      
      if (file.buffer) {
        // H5 端使用 buffer
        workbook = xlsx.read(file.buffer, { type: 'buffer' });
      } else if (file.path) {
        // 小程序端使用文件路径
        workbook = xlsx.readFile(file.path);
      } else {
        throw new BadRequestException('无法读取文件内容');
      }

      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const data = xlsx.utils.sheet_to_json(sheet);

      participants = data.map((row: any, index: number) => ({
        id: `p_${Date.now()}_${index}`,
        name: row['姓名'] || row['name'] || row['姓名 '] || '',
        employeeId: String(row['工号'] || row['employeeId'] || row['工号 '] || index + 1),
        department: row['部门'] || row['department'] || row['部门 '] || '未分配',
        hasWon: false
      })).filter((p: any) => p.name) as any[];

    } catch (error) {
      console.error('解析文件失败:', error);
      throw new BadRequestException('文件解析失败，请确保文件格式正确');
    }

    if (participants.length === 0) {
      throw new BadRequestException('文件中没有找到有效的人员数据，请确保包含"姓名"、"工号"、"部门"列');
    }

    // 保存参与人员
    this.lotteryService.setParticipants(participants);

    return {
      code: 200,
      msg: 'success',
      data: {
        total: participants.length,
        participants
      }
    };
  }

  @Delete('participants')
  @HttpCode(HttpStatus.OK)
  clearParticipants() {
    this.lotteryService.clearAll();
    return {
      code: 200,
      msg: 'success',
      data: { message: '数据已清空' }
    };
  }

  // ============ 奖项管理 ============

  @Get('prizes')
  getPrizes() {
    return {
      code: 200,
      msg: 'success',
      data: this.lotteryService.getPrizes()
    };
  }

  @Post('prizes')
  @HttpCode(HttpStatus.OK)
  addPrize(@Body() body: { name: string; count: number }) {
    if (!body.name || body.name.trim() === '') {
      throw new BadRequestException('奖项名称不能为空');
    }
    if (!body.count || body.count < 1) {
      throw new BadRequestException('奖项数量必须大于0');
    }

    const prize = this.lotteryService.addPrize({
      name: body.name.trim(),
      count: body.count
    });

    return {
      code: 200,
      msg: 'success',
      data: prize
    };
  }

  @Post('prizes/:id')
  @HttpCode(HttpStatus.OK)
  updatePrize(
    @Param('id') id: string,
    @Body() body: { name?: string; count?: number }
  ) {
    const prize = this.lotteryService.updatePrize(id, body);
    return {
      code: 200,
      msg: 'success',
      data: prize
    };
  }

  @Delete('prizes/:id')
  @HttpCode(HttpStatus.OK)
  deletePrize(@Param('id') id: string) {
    this.lotteryService.deletePrize(id);
    return {
      code: 200,
      msg: 'success',
      data: { message: '奖项已删除' }
    };
  }

  @Post('prizes/batch')
  @HttpCode(HttpStatus.OK)
  setPrizes(@Body() body: { prizes: Array<{ name: string; count: number }> }) {
    if (!body.prizes || !Array.isArray(body.prizes)) {
      throw new BadRequestException('奖项数据格式错误');
    }

    const prizes = body.prizes.map((p, index) => ({
      id: `prize_${index + 1}`,
      name: p.name,
      level: `level_${index + 1}`,
      count: p.count,
      drawnCount: 0
    }));

    this.lotteryService.setPrizes(prizes);

    return {
      code: 200,
      msg: 'success',
      data: prizes
    };
  }

  // ============ 抽奖功能 ============

  @Post('draw')
  @HttpCode(HttpStatus.OK)
  draw() {
    const winner = this.lotteryService.draw();
    
    if (!winner) {
      const stats = this.lotteryService.getStatistics();
      if (stats.remainingParticipants === 0) {
        throw new BadRequestException('没有可参与抽奖的人员');
      }
      if (this.lotteryService.getPrizes().length === 0) {
        throw new BadRequestException('请先设置奖项');
      }
      throw new BadRequestException('所有奖项已抽完');
    }

    return {
      code: 200,
      msg: 'success',
      data: winner
    };
  }

  @Post('draw/batch')
  @HttpCode(HttpStatus.OK)
  drawMultiple(@Body() body: { count: number }) {
    const count = body.count || 3;
    const winners = this.lotteryService.drawMultiple(count);

    if (winners.length === 0) {
      throw new BadRequestException('无法进行批量抽奖，请检查参与人员和奖项设置');
    }

    return {
      code: 200,
      msg: 'success',
      data: {
        count: winners.length,
        winners
      }
    };
  }

  // ============ 中奖名单 ============

  @Get('winners')
  getWinners() {
    return {
      code: 200,
      msg: 'success',
      data: this.lotteryService.getWinners()
    };
  }

  // ============ 其他功能 ============

  @Post('reset')
  @HttpCode(HttpStatus.OK)
  reset() {
    const result = this.lotteryService.resetLottery();
    return {
      code: 200,
      msg: 'success',
      data: {
        message: `抽奖已重置，已清空 ${result.winnersCleared} 条中奖记录，${result.participantsCount} 人可重新参与抽奖`
      }
    };
  }

  @Get('statistics')
  getStatistics() {
    return {
      code: 200,
      msg: 'success',
      data: this.lotteryService.getStatistics()
    };
  }

  @Get('export/winners')
  async exportWinners() {
    const winners = this.lotteryService.getWinners();
    
    // 创建 Excel 工作簿
    const workbook = xlsx.utils.book_new();
    
    // 准备数据
    const data = winners.map((w, index) => ({
      '序号': index + 1,
      '姓名': w.name,
      '工号': w.employeeId,
      '部门': w.department,
      '奖项': w.prizeName,
      '中奖时间': new Date(w.wonAt).toLocaleString('zh-CN')
    }));

    // 创建工作表
    const worksheet = xlsx.utils.json_to_sheet(data);
    
    // 设置列宽
    worksheet['!cols'] = [
      { wch: 6 },   // 序号
      { wch: 12 },  // 姓名
      { wch: 12 },  // 工号
      { wch: 15 },  // 部门
      { wch: 12 },  // 奖项
      { wch: 20 }   // 中奖时间
    ];

    xlsx.utils.book_append_sheet(workbook, worksheet, '中奖名单');

    // 生成 Excel 文件
    const buffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    return {
      code: 200,
      msg: 'success',
      data: {
        filename: `中奖名单_${new Date().toISOString().split('T')[0]}.xlsx`,
        count: winners.length
      }
    };
  }
}
