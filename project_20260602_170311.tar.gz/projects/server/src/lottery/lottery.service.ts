export interface Participant {
  id: string;
  name: string;
  employeeId: string;
  department: string;
  hasWon: boolean;
}

export interface Winner {
  id: string;
  name: string;
  employeeId: string;
  department: string;
  prizeName: string;
  prizeLevel: string;
  wonAt: string;
}

export interface Prize {
  id: string;
  name: string;
  level: string;
  count: number;
  drawnCount: number;
}

import { Injectable, BadRequestException } from '@nestjs/common';

@Injectable()
export class LotteryService {
  // 内存存储（生产环境应使用数据库）
  private participants: Participant[] = [];
  private winners: Winner[] = [];
  private prizes: Prize[] = [];
  private prizeIdCounter: number = 1;

  // 获取参与人员列表
  getParticipants(): Participant[] {
    return this.participants;
  }

  // 获取剩余可抽奖人数
  getRemainingCount(): number {
    return this.participants.filter(p => !p.hasWon).length;
  }

  // 设置参与人员（导入时使用）
  setParticipants(participants: Participant[]): void {
    this.participants = participants;
  }

  // 获取中奖名单
  getWinners(): Winner[] {
    return this.winners;
  }

  // 获取奖项列表
  getPrizes(): Prize[] {
    return this.prizes;
  }

  // 添加奖项
  addPrize(prize: { name: string; count: number }): Prize {
    const levels = ['special', 'first', 'second', 'third', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth'];
    const level = levels[Math.min(this.prizes.length, levels.length - 1)];
    
    const newPrize: Prize = {
      id: `prize_${this.prizeIdCounter++}`,
      name: prize.name,
      level,
      count: prize.count,
      drawnCount: 0
    };
    
    this.prizes.push(newPrize);
    return newPrize;
  }

  // 更新奖项
  updatePrize(id: string, data: { name?: string; count?: number }): Prize {
    const index = this.prizes.findIndex(p => p.id === id);
    if (index === -1) {
      throw new BadRequestException('奖项不存在');
    }

    // 检查是否减少数量导致已抽取数量超过新数量
    if (data.count !== undefined && data.count < this.prizes[index].drawnCount) {
      throw new BadRequestException(`奖项数量不能小于已抽取数量(${this.prizes[index].drawnCount})`);
    }

    this.prizes[index] = {
      ...this.prizes[index],
      ...(data.name !== undefined && { name: data.name }),
      ...(data.count !== undefined && { count: data.count })
    };

    return this.prizes[index];
  }

  // 删除奖项
  deletePrize(id: string): void {
    const index = this.prizes.findIndex(p => p.id === id);
    if (index === -1) {
      throw new BadRequestException('奖项不存在');
    }

    if (this.prizes[index].drawnCount > 0) {
      throw new BadRequestException('该奖项已有人中奖，无法删除');
    }

    this.prizes.splice(index, 1);
  }

  // 设置奖项列表（批量设置）
  setPrizes(prizes: Prize[]): void {
    this.prizes = prizes.map((p, index) => ({
      ...p,
      id: p.id || `prize_${index + 1}`,
      drawnCount: 0
    }));
    this.prizeIdCounter = prizes.length + 1;
  }

  // 获取当前奖项
  getCurrentPrize(): Prize | null {
    // 找到第一个还没抽完的奖项
    for (const prize of this.prizes) {
      if (prize.drawnCount < prize.count) {
        return prize;
      }
    }
    return null;
  }

  // 执行单次抽奖
  draw(): Winner | null {
    // 获取未中奖的参与人员
    const eligible = this.participants.filter(p => !p.hasWon);
    
    if (eligible.length === 0) {
      return null;
    }

    // 获取当前奖项
    const currentPrize = this.getCurrentPrize();
    if (!currentPrize) {
      return null;
    }

    // 随机选择一个中奖者
    const randomIndex = Math.floor(Math.random() * eligible.length);
    const winner = eligible[randomIndex];

    // 更新参与人员状态
    const participantIndex = this.participants.findIndex(p => p.id === winner.id);
    if (participantIndex !== -1) {
      this.participants[participantIndex].hasWon = true;
    }

    // 更新奖项抽取数量
    const prizeIndex = this.prizes.findIndex(p => p.id === currentPrize.id);
    if (prizeIndex !== -1) {
      this.prizes[prizeIndex].drawnCount++;
    }

    // 创建中奖记录
    const winnerRecord: Winner = {
      id: `w_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: winner.name,
      employeeId: winner.employeeId,
      department: winner.department,
      prizeName: currentPrize.name,
      prizeLevel: currentPrize.level,
      wonAt: new Date().toISOString()
    };

    this.winners.push(winnerRecord);

    return winnerRecord;
  }

  // 批量抽奖
  drawMultiple(count: number): Winner[] {
    const winners: Winner[] = [];
    const currentPrize = this.getCurrentPrize();
    
    if (!currentPrize) {
      return winners;
    }

    // 计算实际可抽取数量
    const remaining = this.getRemainingCount();
    const prizeRemaining = currentPrize.count - currentPrize.drawnCount;
    const actualCount = Math.min(count, remaining, prizeRemaining);

    for (let i = 0; i < actualCount; i++) {
      const winner = this.draw();
      if (winner) {
        winners.push(winner);
      }
    }

    return winners;
  }

  // 重置抽奖（清空中奖记录，让所有人重新参与）
  resetLottery(): { participantsCount: number; winnersCleared: number } {
    const winnersCleared = this.winners.length;
    
    // 重置所有参与人员的中奖状态
    this.participants = this.participants.map(p => ({
      ...p,
      hasWon: false
    }));

    // 清空中奖名单
    this.winners = [];

    // 重置奖项抽取数量
    this.prizes = this.prizes.map(p => ({
      ...p,
      drawnCount: 0
    }));

    return {
      participantsCount: this.participants.length,
      winnersCleared
    };
  }

  // 清空所有数据
  clearAll(): void {
    this.participants = [];
    this.winners = [];
    this.prizes = this.prizes.map(p => ({
      ...p,
      drawnCount: 0
    }));
  }

  // 获取统计信息
  getStatistics() {
    return {
      totalParticipants: this.participants.length,
      remainingParticipants: this.getRemainingCount(),
      totalWinners: this.winners.length,
      prizes: this.prizes.map(p => ({
        id: p.id,
        name: p.name,
        total: p.count,
        drawn: p.drawnCount,
        remaining: p.count - p.drawnCount
      }))
    };
  }
}
