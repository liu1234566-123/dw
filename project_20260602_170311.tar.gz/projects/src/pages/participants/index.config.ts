export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: '人员管理',
      navigationBarBackgroundColor: '#1A1A2E',
      navigationBarTextStyle: 'white'
    })
  : {
      navigationBarTitleText: '人员管理',
      navigationBarBackgroundColor: '#1A1A2E',
      navigationBarTextStyle: 'white'
    }
