import { View, Text } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState, useRef } from 'react'
import { Network } from '@/network'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Upload, Trash2, Users, Crown, ArrowLeft } from 'lucide-react-taro'

interface Participant {
  id: string
  name: string
  employeeId: string
  department: string
  hasWon: boolean
}

const ParticipantsPage = () => {
  const [participants, setParticipants] = useState<Participant[]>([])
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement | null>(null)

  // 平台检测
  const env = Taro.getEnv()
  const isMiniApp = env === Taro.ENV_TYPE.WEAPP || env === Taro.ENV_TYPE.TT

  useDidShow(() => {
    fetchParticipants()
  })

  const fetchParticipants = async () => {
    setLoading(true)
    try {
      const res = await Network.request({ url: '/api/participants' })
      console.log('Participants response:', res.data)
      if (res.data?.data) {
        setParticipants(res.data.data)
      }
    } catch (error) {
      console.error('Failed to fetch participants:', error)
      Taro.showToast({ title: '获取人员列表失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  // 小程序端上传
  const handleMiniAppUpload = async () => {
    try {
      const res = await Taro.chooseMessageFile({
        count: 1,
        type: 'file',
        extension: ['xlsx', 'xls', 'csv']
      })

      if (res.tempFiles.length === 0) return

      const file = res.tempFiles[0]
      setUploading(true)

      const uploadRes = await Network.uploadFile({
        url: '/api/participants/upload',
        filePath: file.path,
        name: 'file'
      })

      console.log('Upload response:', uploadRes.data)

      const resData = uploadRes.data as { code?: number; msg?: string }
      if (resData?.code === 200) {
        Taro.showToast({ title: '导入成功', icon: 'success' })
        fetchParticipants()
      } else {
        Taro.showToast({ title: resData?.msg || '导入失败', icon: 'none' })
      }
    } catch (error) {
      console.error('Upload failed:', error)
      Taro.showToast({ title: '上传失败，请重试', icon: 'none' })
    } finally {
      setUploading(false)
    }
  }

  // H5端上传
  const handleH5Upload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setUploading(true)

    try {
      // 构建 FormData
      const formData = new FormData()
      formData.append('file', file)

      // 直接使用 fetch 上传
      const response = await fetch('/api/participants/upload', {
        method: 'POST',
        body: formData
      })

      const result = await response.json()
      console.log('Upload result:', result)

      if (result.code === 200) {
        Taro.showToast({ title: '导入成功', icon: 'success' })
        fetchParticipants()
      } else {
        Taro.showToast({ title: result.msg || '导入失败', icon: 'none' })
      }
    } catch (error) {
      console.error('H5 upload failed:', error)
      Taro.showToast({ title: '上传失败，请重试', icon: 'none' })
    } finally {
      setUploading(false)
      // 重置 input
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    }
  }

  // 统一上传入口
  const handleUpload = () => {
    if (isMiniApp) {
      handleMiniAppUpload()
    } else {
      // H5 端触发 file input
      fileInputRef.current?.click()
    }
  }

  const handleClearAll = async () => {
    const res = await Taro.showModal({
      title: '确认清空',
      content: '确定要清空所有人员吗？此操作不可恢复。'
    })

    if (!res.confirm) return

    try {
      const result = await Network.request({
        url: '/api/participants',
        method: 'DELETE'
      })

      if (result.data?.code === 200) {
        Taro.showToast({ title: '已清空', icon: 'success' })
        setParticipants([])
      }
    } catch (error) {
      console.error('Clear failed:', error)
      Taro.showToast({ title: '操作失败', icon: 'none' })
    }
  }

  const goBack = () => {
    Taro.navigateBack()
  }

  const wonCount = participants.filter(p => p.hasWon).length
  const total = participants.length
  const uploadProgress = total > 0 ? (wonCount / total) * 100 : 0

  return (
    <View className="min-h-screen bg-slate-900">
      {/* H5 隐藏的 file input */}
      {!isMiniApp && (
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls,.csv"
          style={{ display: 'none' }}
          onChange={handleH5Upload}
        />
      )}

      {/* 头部 */}
      <View className="sticky top-0 z-10 bg-slate-900 border-b border-slate-800 px-4 py-3">
        <View className="flex items-center justify-between">
          <View className="flex items-center">
            <Button variant="ghost" size="sm" onClick={goBack} className="p-0 mr-2">
              <ArrowLeft size={20} color="#9CA3AF" />
            </Button>
            <Text className="block text-slate-100 text-lg font-semibold">人员管理</Text>
          </View>
          <View className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              className="border-rose-500 text-rose-400"
              onClick={handleClearAll}
            >
              <Trash2 size={16} color="#E94560" />
              <Text className="ml-1">清空</Text>
            </Button>
            <Button
              size="sm"
              className="bg-amber-500 text-slate-900"
              onClick={handleUpload}
              disabled={uploading}
            >
              <Upload size={16} color="#1A1A2E" />
              <Text className="ml-1">{uploading ? '导入中...' : '导入'}</Text>
            </Button>
          </View>
        </View>
      </View>

      {/* 统计信息 */}
      <View className="px-4 py-4 border-b border-slate-800">
        <View className="flex items-center justify-between mb-3">
          <View className="flex items-center gap-2">
            <Users size={20} color="#9CA3AF" />
            <Text className="block text-slate-300">总人数</Text>
            <Text className="block text-amber-400 font-bold text-lg">{total}</Text>
          </View>
          <View className="flex items-center gap-2">
            <Crown size={20} color="#D4A849" />
            <Text className="block text-slate-300">已中奖</Text>
            <Text className="block text-amber-400 font-bold text-lg">{wonCount}</Text>
          </View>
        </View>
        <Progress value={uploadProgress} className="h-2" />
        <Text className="block text-slate-500 text-xs mt-2 text-center">
          中奖率 {total > 0 ? ((wonCount / total) * 100).toFixed(1) : 0}%
        </Text>
      </View>

      {/* 人员列表 */}
      <ScrollArea className="h-[calc(100vh-180px)]">
        <View className="px-4 py-4">
          {loading ? (
            <View className="flex items-center justify-center py-12">
              <Text className="block text-slate-500">加载中...</Text>
            </View>
          ) : participants.length === 0 ? (
            <View className="flex flex-col items-center justify-center py-16">
              <Users size={48} color="#4B5563" />
              <Text className="block text-slate-500 text-lg mt-4">暂无参与人员</Text>
              <Text className="block text-slate-600 text-sm mt-2">
                请点击右上角导入按钮上传人员名单
              </Text>
              <Text className="block text-slate-600 text-sm mt-1">
                支持 Excel (.xlsx, .xls) 或 CSV 格式
              </Text>
            </View>
          ) : (
            <View className="flex flex-col gap-3">
              {participants.map((item) => (
                <Card
                  key={item.id}
                  className={`bg-slate-800 border-slate-700 ${item.hasWon ? 'border-l-4 border-l-amber-500' : ''}`}
                >
                  <CardContent className="p-4">
                    <View className="flex items-center justify-between">
                      <View className="flex-1">
                        <View className="flex items-center gap-2 mb-1">
                          <Text className="block text-slate-100 font-semibold text-lg">
                            {item.name}
                          </Text>
                          {item.hasWon && (
                            <Badge className="bg-amber-500 text-slate-900">
                              已中奖
                            </Badge>
                          )}
                        </View>
                        <View className="flex items-center gap-3">
                          <Text className="block text-slate-400 text-sm">
                            工号：{item.employeeId}
                          </Text>
                          <Text className="block text-slate-400 text-sm">
                            {item.department}
                          </Text>
                        </View>
                      </View>
                    </View>
                  </CardContent>
                </Card>
              ))}
            </View>
          )}
        </View>
      </ScrollArea>

      {/* 文件格式提示 */}
      <View className="fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 px-4 py-3">
        <Text className="block text-slate-500 text-xs text-center">
          文件格式要求：姓名、工号、部门（首行为表头）
        </Text>
      </View>
    </View>
  )
}

export default ParticipantsPage
