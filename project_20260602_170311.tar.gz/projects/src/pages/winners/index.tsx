import { View, Text } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { Network } from '@/network'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Trophy, ArrowLeft, Clock } from 'lucide-react-taro'

interface Winner {
  id: string
  name: string
  employeeId: string
  department: string
  prizeName: string
  prizeLevel: string
  wonAt: string
}

// 奖项级别对应的颜色
const getPrizeColor = (level: string) => {
  switch (level) {
    case 'special': return 'bg-rose-500'
    case 'first': return 'bg-amber-500'
    case 'second': return 'bg-blue-500'
    case 'third': return 'bg-emerald-500'
    default: return 'bg-amber-500'
  }
}

const WinnersPage = () => {
  const [winners, setWinners] = useState<Winner[]>([])
  const [loading, setLoading] = useState(false)

  useDidShow(() => {
    fetchWinners()
  })

  const fetchWinners = async () => {
    setLoading(true)
    try {
      const res = await Network.request({ url: '/api/winners' })
      console.log('Winners response:', res.data)
      if (res.data?.data) {
        setWinners(res.data.data)
      }
    } catch (error) {
      console.error('Failed to fetch winners:', error)
      Taro.showToast({ title: '获取中奖名单失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  const goBack = () => {
    Taro.navigateBack()
  }

  const formatTime = (dateStr: string) => {
    if (!dateStr) return ''
    const date = new Date(dateStr)
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
  }

  return (
    <View className="min-h-screen bg-slate-900">
      {/* 头部 */}
      <View className="sticky top-0 z-10 bg-slate-900 border-b border-slate-800 px-4 py-3">
        <View className="flex items-center">
          <Button variant="ghost" size="sm" onClick={goBack} className="p-0 mr-2">
            <ArrowLeft size={20} color="#9CA3AF" />
          </Button>
          <View className="flex items-center gap-2">
            <Trophy size={22} color="#D4A849" />
            <Text className="block text-slate-100 text-lg font-semibold">中奖名单</Text>
          </View>
          {winners.length > 0 && (
            <Badge className="ml-2 bg-amber-500 text-slate-900">
              {winners.length} 人
            </Badge>
          )}
        </View>
      </View>

      {/* 中奖名单 */}
      <ScrollArea className="h-[calc(100vh-60px)]">
        <View className="px-4 py-4">
          {loading ? (
            <View className="flex items-center justify-center py-12">
              <Text className="block text-slate-500">加载中...</Text>
            </View>
          ) : winners.length === 0 ? (
            <View className="flex flex-col items-center justify-center py-16">
              <Trophy size={48} color="#4B5563" />
              <Text className="block text-slate-500 text-lg mt-4">暂无中奖记录</Text>
              <Text className="block text-slate-600 text-sm mt-2">
                开始抽奖后，中奖者将在这里显示
              </Text>
            </View>
          ) : (
            <View className="flex flex-col gap-3">
              {winners.map((item, index) => (
                <Card
                  key={item.id}
                  className="bg-slate-800 border-slate-700 border-l-4 border-l-amber-500"
                >
                  <CardContent className="p-4">
                    <View className="flex items-start justify-between">
                      <View className="flex-1">
                        <View className="flex items-center gap-3 mb-2">
                          <View className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center">
                            <Text className="block text-slate-900 font-bold">
                              {index + 1}
                            </Text>
                          </View>
                          <Text className="block text-slate-100 font-semibold text-lg">
                            {item.name}
                          </Text>
                        </View>
                        <View className="ml-11">
                          <View className="flex items-center gap-3 mb-1">
                            <Text className="block text-slate-400 text-sm">
                              工号：{item.employeeId}
                            </Text>
                            <Text className="block text-slate-400 text-sm">
                              {item.department}
                            </Text>
                          </View>
                          <View className="flex items-center gap-1 mt-2">
                            <Clock size={14} color="#6B7280" />
                            <Text className="block text-slate-500 text-xs">
                              {formatTime(item.wonAt)}
                            </Text>
                          </View>
                        </View>
                      </View>
                      <Badge className={`${getPrizeColor(item.prizeLevel)} text-white`}>
                        {item.prizeName || '幸运大奖'}
                      </Badge>
                    </View>
                  </CardContent>
                </Card>
              ))}
            </View>
          )}
        </View>
      </ScrollArea>
    </View>
  )
}

export default WinnersPage
