export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: '中奖名单',
      navigationBarBackgroundColor: '#1A1A2E',
      navigationBarTextStyle: 'white'
    })
  : {
      navigationBarTitleText: '中奖名单',
      navigationBarBackgroundColor: '#1A1A2E',
      navigationBarTextStyle: 'white'
    }
