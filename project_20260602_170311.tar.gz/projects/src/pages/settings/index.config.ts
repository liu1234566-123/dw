export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: '奖项设置',
      navigationBarBackgroundColor: '#0f172a',
      navigationBarTextStyle: 'white'
    })
  : {
      navigationBarTitleText: '奖项设置',
      navigationBarBackgroundColor: '#0f172a',
      navigationBarTextStyle: 'white'
    }
