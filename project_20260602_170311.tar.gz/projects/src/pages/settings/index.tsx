import { useState } from 'react'
import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Plus, Trash2, Pencil, Award, ArrowLeft } from 'lucide-react-taro'
import { Network } from '@/network'

interface Prize {
  id: string
  name: string
  level: string
  count: number
  drawnCount: number
}

export default function SettingsPage() {
  const [prizes, setPrizes] = useState<Prize[]>([])
  const [loading, setLoading] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [currentPrize, setCurrentPrize] = useState<Prize | null>(null)
  const [prizeName, setPrizeName] = useState('')
  const [prizeCount, setPrizeCount] = useState('1')

  const fetchPrizes = async () => {
    try {
      const res = await Network.request({
        url: '/api/prizes',
        method: 'GET'
      })
      console.log('获取奖项列表:', res.data)
      if (res.data?.code === 200) {
        setPrizes(res.data.data || [])
      }
    } catch (error) {
      console.error('获取奖项失败:', error)
      Taro.showToast({ title: '获取奖项失败', icon: 'none' })
    }
  }

  useDidShow(() => {
    fetchPrizes()
  })

  const handleAddPrize = () => {
    setPrizeName('')
    setPrizeCount('1')
    setAddDialogOpen(true)
  }

  const handleEditPrize = (prize: Prize) => {
    setCurrentPrize(prize)
    setPrizeName(prize.name)
    setPrizeCount(String(prize.count))
    setEditDialogOpen(true)
  }

  const handleSaveAdd = async () => {
    if (!prizeName.trim()) {
      Taro.showToast({ title: '请输入奖项名称', icon: 'none' })
      return
    }
    const count = parseInt(prizeCount, 10)
    if (Number.isNaN(count) || count < 1) {
      Taro.showToast({ title: '请输入有效数量', icon: 'none' })
      return
    }

    setLoading(true)
    try {
      const res = await Network.request({
        url: '/api/prizes',
        method: 'POST',
        data: { name: prizeName.trim(), count }
      })
      console.log('添加奖项:', res.data)
      if (res.data?.code === 200) {
        Taro.showToast({ title: '添加成功', icon: 'success' })
        setAddDialogOpen(false)
        fetchPrizes()
      } else {
        Taro.showToast({ title: res.data?.msg || '添加失败', icon: 'none' })
      }
    } catch (error) {
      console.error('添加奖项失败:', error)
      Taro.showToast({ title: '添加失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  const handleSaveEdit = async () => {
    if (!currentPrize) return
    if (!prizeName.trim()) {
      Taro.showToast({ title: '请输入奖项名称', icon: 'none' })
      return
    }
    const count = parseInt(prizeCount, 10)
    if (Number.isNaN(count) || count < 1) {
      Taro.showToast({ title: '请输入有效数量', icon: 'none' })
      return
    }
    if (count < currentPrize.drawnCount) {
      Taro.showToast({ title: `数量不能小于已抽取数量(${currentPrize.drawnCount})`, icon: 'none' })
      return
    }

    setLoading(true)
    try {
      const res = await Network.request({
        url: `/api/prizes/${currentPrize.id}`,
        method: 'POST',
        data: { name: prizeName.trim(), count }
      })
      console.log('更新奖项:', res.data)
      if (res.data?.code === 200) {
        Taro.showToast({ title: '更新成功', icon: 'success' })
        setEditDialogOpen(false)
        fetchPrizes()
      } else {
        Taro.showToast({ title: res.data?.msg || '更新失败', icon: 'none' })
      }
    } catch (error) {
      console.error('更新奖项失败:', error)
      Taro.showToast({ title: '更新失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  const handleDeletePrize = async (prize: Prize) => {
    if (prize.drawnCount > 0) {
      Taro.showToast({ title: '该奖项已有人中奖，无法删除', icon: 'none' })
      return
    }

    const result = await Taro.showModal({
      title: '确认删除',
      content: `确定要删除【${prize.name}】吗？`,
      confirmColor: '#E94560'
    })

    if (result.confirm) {
      try {
        const res = await Network.request({
          url: `/api/prizes/${prize.id}`,
          method: 'DELETE'
        })
        console.log('删除奖项:', res.data)
        if (res.data?.code === 200) {
          Taro.showToast({ title: '删除成功', icon: 'success' })
          fetchPrizes()
        } else {
          Taro.showToast({ title: res.data?.msg || '删除失败', icon: 'none' })
        }
      } catch (error) {
        console.error('删除奖项失败:', error)
        Taro.showToast({ title: '删除失败', icon: 'none' })
      }
    }
  }

  const getPrizeColor = (index: number) => {
    const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE']
    return colors[index % colors.length]
  }

  return (
    <View className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* 头部导航 */}
      <View className="sticky top-0 z-50 bg-slate-900 backdrop-blur-md border-b border-slate-700">
        <View className="flex items-center justify-between px-4 py-3 md:px-6 md:py-4 max-w-4xl mx-auto">
          <View className="flex items-center">
            <View onClick={() => Taro.navigateBack()} className="p-2 -ml-2">
              <ArrowLeft size={24} color="#fff" />
            </View>
            <Text className="block ml-2 text-lg font-bold text-white md:text-xl">奖项设置</Text>
          </View>
          <Button
            onClick={handleAddPrize}
            className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0"
          >
            <Plus size={18} color="#fff" className="mr-1" />
            <Text className="text-white font-medium">添加奖项</Text>
          </Button>
        </View>
      </View>

      {/* 主要内容 */}
      <ScrollView scrollY className="h-screen pb-20">
        <View className="px-4 py-4 md:px-6 md:py-6 max-w-4xl mx-auto">
          {/* 提示信息 */}
          <Card className="mb-4 bg-slate-800 border-slate-700">
            <CardContent className="p-4">
              <View className="flex items-start">
                <Award size={20} color="#fbbf24" className="mr-3 mt-1 flex-shrink-0" />
                <View className="flex-1">
                  <Text className="block text-yellow-400 font-medium mb-1">奖项设置说明</Text>
                  <Text className="block text-gray-400 text-sm">
                    添加奖项后，抽奖将按照添加顺序依次进行。已有人中奖的奖项无法删除。
                  </Text>
                </View>
              </View>
            </CardContent>
          </Card>

          {/* 奖项列表 */}
          {prizes.length === 0 ? (
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-8 text-center">
                <Award size={48} color="#4B5563" className="mx-auto mb-4" />
                <Text className="block text-gray-400 text-lg mb-2">暂无奖项</Text>
                <Text className="block text-gray-500 text-sm mb-4">点击右上角【添加奖项】开始设置</Text>
              </CardContent>
            </Card>
          ) : (
            <View>
              {prizes.map((prize, index) => (
                <Card key={prize.id} className="mb-3 bg-slate-800 border-slate-700 overflow-hidden">
                  <View 
                    className="h-1"
                    style={{ backgroundColor: getPrizeColor(index) }}
                  />
                  <CardContent className="p-4">
                    <View className="flex items-center justify-between">
                      <View className="flex-1">
                        <View className="flex items-center mb-2">
                          <View 
                            className="w-3 h-3 rounded-full mr-2"
                            style={{ backgroundColor: getPrizeColor(index) }}
                          />
                          <Text className="block text-white font-semibold text-lg">{prize.name}</Text>
                          {prize.drawnCount > 0 && (
                            <Badge className="ml-2 bg-green-600 text-white text-xs">已抽 {prize.drawnCount} 人</Badge>
                          )}
                        </View>
                        <View className="flex items-center text-gray-400 text-sm">
                          <Text className="block">总数量: {prize.count} 人</Text>
                          <Text className="block mx-2">•</Text>
                          <Text className="block">剩余: {prize.count - prize.drawnCount} 人</Text>
                        </View>
                        {/* 进度条 */}
                        <View className="mt-3 h-2 bg-slate-700 rounded-full overflow-hidden">
                          <View 
                            className="h-full rounded-full transition-all duration-300"
                            style={{ 
                              width: `${prize.count > 0 ? (prize.drawnCount / prize.count) * 100 : 0}%`,
                              backgroundColor: getPrizeColor(index)
                            }}
                          />
                        </View>
                      </View>
                      <View className="flex items-center gap-2 ml-4">
                        <View 
                          onClick={() => handleEditPrize(prize)}
                          className="p-2 bg-slate-700 rounded-lg active:bg-slate-600"
                        >
                          <Pencil size={18} color="#60A5FA" />
                        </View>
                        <View 
                          onClick={() => handleDeletePrize(prize)}
                          className={`p-2 rounded-lg ${prize.drawnCount > 0 ? 'bg-slate-700 opacity-50' : 'bg-slate-700 active:bg-red-600'}`}
                        >
                          <Trash2 size={18} color={prize.drawnCount > 0 ? '#6B7280' : '#F87171'} />
                        </View>
                      </View>
                    </View>
                  </CardContent>
                </Card>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      {/* 添加奖项弹窗 */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">添加奖项</DialogTitle>
          </DialogHeader>
          <View className="py-4">
            <View className="mb-4">
              <Text className="block text-gray-300 text-sm mb-2">奖项名称</Text>
              <View className="bg-slate-700 rounded-lg px-3 py-2">
                <Input
                  className="w-full bg-transparent text-white"
                  placeholder="如：特等奖、一等奖"
                  value={prizeName}
                  onInput={(e) => setPrizeName(e.detail.value)}
                />
              </View>
            </View>
            <View>
              <Text className="block text-gray-300 text-sm mb-2">奖项数量</Text>
              <View className="bg-slate-700 rounded-lg px-3 py-2">
                <Input
                  className="w-full bg-transparent text-white"
                  type="number"
                  placeholder="中奖人数"
                  value={prizeCount}
                  onInput={(e) => setPrizeCount(e.detail.value)}
                />
              </View>
            </View>
          </View>
          <DialogFooter>
            <Button onClick={() => setAddDialogOpen(false)} variant="outline" className="border-slate-600 text-gray-300">
              取消
            </Button>
            <Button onClick={handleSaveAdd} disabled={loading} className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
              {loading ? '保存中...' : '确定'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 编辑奖项弹窗 */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-white">编辑奖项</DialogTitle>
          </DialogHeader>
          <View className="py-4">
            <View className="mb-4">
              <Text className="block text-gray-300 text-sm mb-2">奖项名称</Text>
              <View className="bg-slate-700 rounded-lg px-3 py-2">
                <Input
                  className="w-full bg-transparent text-white"
                  placeholder="奖项名称"
                  value={prizeName}
                  onInput={(e) => setPrizeName(e.detail.value)}
                />
              </View>
            </View>
            <View>
              <Text className="block text-gray-300 text-sm mb-2">奖项数量</Text>
              <View className="bg-slate-700 rounded-lg px-3 py-2">
                <Input
                  className="w-full bg-transparent text-white"
                  type="number"
                  placeholder="中奖人数"
                  value={prizeCount}
                  onInput={(e) => setPrizeCount(e.detail.value)}
                />
              </View>
              {currentPrize && currentPrize.drawnCount > 0 && (
                <Text className="block text-yellow-400 text-xs mt-1">
                  已抽取 {currentPrize.drawnCount} 人，数量不能小于此值
                </Text>
              )}
            </View>
          </View>
          <DialogFooter>
            <Button onClick={() => setEditDialogOpen(false)} variant="outline" className="border-slate-600 text-gray-300">
              取消
            </Button>
            <Button onClick={handleSaveEdit} disabled={loading} className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
              {loading ? '保存中...' : '保存'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </View>
  )
}
