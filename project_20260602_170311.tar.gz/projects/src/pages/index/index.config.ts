export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: '年会抽奖',
      navigationBarBackgroundColor: '#1A1A2E',
      navigationBarTextStyle: 'white'
    })
  : {
      navigationBarTitleText: '年会抽奖',
      navigationBarBackgroundColor: '#1A1A2E',
      navigationBarTextStyle: 'white'
    }
