import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import { Network } from '@/network'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Gift, Users, Trophy, Sparkles, RotateCcw, Download, Settings } from 'lucide-react-taro'
import './index.css'

interface Participant {
  id: string
  name: string
  employeeId: string
  department: string
  hasWon: boolean
}

interface Winner {
  id: string
  name: string
  employeeId: string
  department: string
  prizeName: string
  prizeLevel: string
  wonAt: string
}

interface PrizeProgress {
  id?: string
  name: string
  total: number
  drawn: number
  remaining: number
}

interface Statistics {
  totalParticipants: number
  remainingParticipants: number
  totalWinners: number
  prizes: PrizeProgress[]
}

const IndexPage = () => {
  const [participants, setParticipants] = useState<Participant[]>([])
  const [winners, setWinners] = useState<Winner[]>([])
  const [prizeProgress, setPrizeProgress] = useState<PrizeProgress[]>([])
  const [statistics, setStatistics] = useState<Statistics | null>(null)
  const [isSpinning, setIsSpinning] = useState(false)
  const [currentName, setCurrentName] = useState('')
  const [showWinnerDialog, setShowWinnerDialog] = useState(false)
  const [showResetDialog, setShowResetDialog] = useState(false)
  const [currentWinner, setCurrentWinner] = useState<Winner | null>(null)
  const [batchWinners, setBatchWinners] = useState<Winner[]>([])
  const [showBatchDialog, setShowBatchDialog] = useState(false)

  useDidShow(() => {
    fetchData()
  })

  const fetchData = async () => {
    try {
      const [participantsRes, winnersRes, statsRes] = await Promise.all([
        Network.request({ url: '/api/participants' }),
        Network.request({ url: '/api/winners' }),
        Network.request({ url: '/api/statistics' })
      ])
      console.log('Participants response:', participantsRes.data)
      console.log('Winners response:', winnersRes.data)
      console.log('Statistics response:', statsRes.data)
      
      if (participantsRes.data?.data) {
        setParticipants(participantsRes.data.data)
      }
      if (winnersRes.data?.data) {
        setWinners(winnersRes.data.data)
      }
      if (statsRes.data?.data) {
        setStatistics(statsRes.data.data)
        setPrizeProgress(statsRes.data.data.prizes || [])
      }
    } catch (error) {
      console.error('Failed to fetch data:', error)
    }
  }

  const eligibleParticipants = participants.filter(p => !p.hasWon)
  const totalParticipants = participants.length
  const totalWinners = winners.length
  const remainingParticipants = statistics?.remainingParticipants || 0

  const handleDraw = async () => {
    if (prizeProgress.length === 0) {
      Taro.showToast({ title: '请先设置奖项', icon: 'none' })
      return
    }
    if (eligibleParticipants.length === 0) {
      Taro.showToast({ title: '没有可参与抽奖的人员', icon: 'none' })
      return
    }

    setIsSpinning(true)

    // 抽奖动画：快速滚动名字
    let spinCount = 0
    const totalSpins = 30
    const spinInterval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * eligibleParticipants.length)
      setCurrentName(eligibleParticipants[randomIndex].name)
      spinCount++

      if (spinCount >= totalSpins) {
        clearInterval(spinInterval)
        performDraw()
      }
    }, 100)
  }

  const performDraw = async () => {
    try {
      const res = await Network.request({
        url: '/api/draw',
        method: 'POST'
      })
      console.log('Draw result:', res.data)

      if (res.data?.data) {
        setCurrentWinner(res.data.data)
        setShowWinnerDialog(true)
        fetchData() // 刷新数据
      }
    } catch (error) {
      console.error('Draw failed:', error)
      Taro.showToast({ title: '抽奖失败，请重试', icon: 'none' })
    } finally {
      setIsSpinning(false)
      setCurrentName('')
    }
  }

  // 批量抽奖
  const handleBatchDraw = async (count: number) => {
    if (prizeProgress.length === 0) {
      Taro.showToast({ title: '请先设置奖项', icon: 'none' })
      return
    }
    if (eligibleParticipants.length === 0) {
      Taro.showToast({ title: '没有可参与抽奖的人员', icon: 'none' })
      return
    }

    try {
      Taro.showLoading({ title: '抽奖中...' })
      const res = await Network.request({
        url: '/api/draw/batch',
        method: 'POST',
        data: { count }
      })
      console.log('Batch draw result:', res.data)

      if (res.data?.data?.winners) {
        setBatchWinners(res.data.data.winners)
        setShowBatchDialog(true)
        fetchData()
      }
    } catch (error) {
      console.error('Batch draw failed:', error)
      Taro.showToast({ title: '批量抽奖失败', icon: 'none' })
    } finally {
      Taro.hideLoading()
    }
  }

  // 重置抽奖
  const handleReset = async () => {
    try {
      Taro.showLoading({ title: '重置中...' })
      const res = await Network.request({
        url: '/api/reset',
        method: 'POST'
      })
      console.log('Reset result:', res.data)
      
      Taro.showToast({ title: '重置成功', icon: 'success' })
      setShowResetDialog(false)
      fetchData()
    } catch (error) {
      console.error('Reset failed:', error)
      Taro.showToast({ title: '重置失败', icon: 'none' })
    } finally {
      Taro.hideLoading()
    }
  }

  // 导出中奖名单
  const handleExport = async () => {
    try {
      Taro.showLoading({ title: '导出中...' })
      const res = await Network.request({
        url: '/api/export/winners'
      })
      console.log('Export result:', res.data)

      if (res.data?.data?.fileData) {
        // 在小程序中需要下载文件
        const fileData = res.data.data.fileData
        const filename = res.data.data.filename
        
        // 将 base64 转换为文件并保存
        const fs = Taro.getFileSystemManager()
        const filePath = `${Taro.env.USER_DATA_PATH}/${filename}`
        
        fs.writeFile({
          filePath,
          data: fileData,
          encoding: 'base64',
          success: () => {
            Taro.hideLoading()
            Taro.showToast({ title: '导出成功', icon: 'success' })
            // 在小程序中打开文档
            Taro.openDocument({
              filePath,
              fileType: 'xlsx',
              showMenu: true
            })
          },
          fail: (err) => {
            console.error('Save file failed:', err)
            Taro.hideLoading()
            Taro.showToast({ title: '保存文件失败', icon: 'none' })
          }
        })
      }
    } catch (error) {
      console.error('Export failed:', error)
      Taro.hideLoading()
      Taro.showToast({ title: '导出失败', icon: 'none' })
    }
  }

  const goToParticipants = () => {
    Taro.navigateTo({ url: '/pages/participants/index' })
  }

  const goToWinners = () => {
    Taro.navigateTo({ url: '/pages/winners/index' })
  }

  const goToSettings = () => {
    Taro.navigateTo({ url: '/pages/settings/index' })
  }

  // 获取当前奖项
  const getCurrentPrizeDisplay = () => {
    if (!prizeProgress || prizeProgress.length === 0) return null
    const current = prizeProgress.find(p => p.remaining > 0)
    return current
  }

  const currentPrizeDisplay = getCurrentPrizeDisplay()

  // 获取奖项颜色
  const getPrizeColor = (index: number) => {
    const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8']
    return colors[index % colors.length]
  }

  return (
    <View className="lottery-page">
      {/* 背景装饰 */}
      <View className="absolute top-0 left-0 right-0 h-64 overflow-hidden pointer-events-none">
        <View className="absolute top-10 left-1/2 transform -translate-x-1/2 w-48 h-48 bg-amber-500 rounded-full blur-3xl opacity-20" />
      </View>

      {/* 主内容 - 响应式容器 */}
      <ScrollView scrollY className="h-screen">
        <View className="relative z-10 min-h-screen flex flex-col max-w-2xl mx-auto px-4 md:px-6 py-safe">
          {/* 头部标题 */}
          <View className="text-center pt-8 md:pt-12 pb-4">
            <View className="flex items-center justify-center gap-2 mb-2">
              <Sparkles size={28} color="#D4A849" />
              <Text className="block text-amber-400 text-2xl font-bold">抽奖</Text>
              <Sparkles size={28} color="#D4A849" />
            </View>
            <View className="w-32 h-px bg-amber-500 mx-auto mt-3" />
          </View>

          {/* 当前奖项显示 */}
          {currentPrizeDisplay && (
            <View className="mb-4">
              <View className="px-4 py-2 bg-amber-500 bg-opacity-20 rounded-lg border border-amber-500 border-opacity-50">
                <Text className="block text-amber-400 text-center text-sm">
                  当前奖项：
                  <Text className="font-bold">{currentPrizeDisplay.name}</Text>
                  {' '}(剩余 {currentPrizeDisplay.remaining} 名)
                </Text>
              </View>
            </View>
          )}

          {/* 无奖项提示 */}
          {prizeProgress.length === 0 && (
            <View className="mb-4 px-4 py-3 bg-rose-500 rounded-lg opacity-80">
              <Text className="block text-white text-sm text-center">
                请先设置奖项，点击下方【奖项设置】按钮
              </Text>
            </View>
          )}

          {/* 抽奖区域 */}
          <View className="flex flex-col items-center py-4 md:py-8">
            {/* 抽奖按钮 */}
            <View className="relative mb-6">
              {/* 光晕效果 */}
              <View className="absolute inset-0 bg-amber-500 rounded-full blur-xl opacity-30 animate-pulse" />
              
              <Button
                className="lottery-button relative w-32 h-32 md:w-40 md:h-40 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 border-4 border-amber-300 shadow-lg"
                onClick={handleDraw}
                disabled={isSpinning || eligibleParticipants.length === 0 || prizeProgress.length === 0}
              >
                <View className="flex flex-col items-center">
                  <Gift size={32} color="#1A1A2E" />
                  <Text className="block text-slate-900 font-bold text-base mt-2">
                    {isSpinning ? '抽奖中...' : '抽奖'}
                  </Text>
                </View>
              </Button>
            </View>

            {/* 滚动名字显示 */}
            {isSpinning && (
              <View className="mb-4 px-6 py-3 bg-slate-800 rounded-xl border border-amber-500">
                <Text className="block text-amber-400 text-xl font-bold text-center">
                  {currentName}
                </Text>
              </View>
            )}

            {/* 批量抽奖按钮 */}
            <View className="flex gap-3 mb-6">
              <Button
                variant="outline"
                size="sm"
                className="bg-slate-800 border-amber-500 text-amber-400 px-4"
                onClick={() => handleBatchDraw(3)}
                disabled={isSpinning || eligibleParticipants.length < 3 || prizeProgress.length === 0}
              >
                <Text>一次抽3人</Text>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="bg-slate-800 border-amber-500 text-amber-400 px-4"
                onClick={() => handleBatchDraw(5)}
                disabled={isSpinning || eligibleParticipants.length < 5 || prizeProgress.length === 0}
              >
                <Text>一次抽5人</Text>
              </Button>
            </View>

            {/* 统计信息 */}
            <View className="w-full mb-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4">
                  <View className="flex justify-around">
                    <View className="text-center">
                      <View className="flex items-center justify-center gap-1 mb-1">
                        <Users size={18} color="#9CA3AF" />
                        <Text className="block text-slate-400 text-sm">参与人数</Text>
                      </View>
                      <Text className="block text-slate-100 text-2xl font-bold">{totalParticipants}</Text>
                    </View>
                    <View className="w-px bg-slate-700" />
                    <View className="text-center">
                      <View className="flex items-center justify-center gap-1 mb-1">
                        <Trophy size={18} color="#D4A849" />
                        <Text className="block text-amber-400 text-sm">已中奖</Text>
                      </View>
                      <Text className="block text-amber-400 text-2xl font-bold">{totalWinners}</Text>
                    </View>
                    <View className="w-px bg-slate-700" />
                    <View className="text-center">
                      <Text className="block text-slate-400 text-sm mb-1">剩余</Text>
                      <Text className="block text-emerald-400 text-2xl font-bold">{remainingParticipants}</Text>
                    </View>
                  </View>
                </CardContent>
              </Card>
            </View>

            {/* 奖项进度 */}
            {prizeProgress && prizeProgress.length > 0 && (
              <View className="w-full mb-4">
                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="p-3">
                    <View className="flex items-center justify-between mb-2">
                      <Text className="block text-slate-400 text-sm">奖项进度</Text>
                      <View onClick={goToSettings} className="p-1">
                        <Settings size={16} color="#9CA3AF" />
                      </View>
                    </View>
                    {prizeProgress.map((prize, index) => (
                      <View key={prize.id || index} className="mb-2 last:mb-0">
                        <View className="flex items-center justify-between mb-1">
                          <View className="flex items-center">
                            <View 
                              className="w-2 h-2 rounded-full mr-2"
                              style={{ backgroundColor: getPrizeColor(index) }}
                            />
                            <Text className="block text-slate-300 text-sm">{prize.name}</Text>
                          </View>
                          <Text className="block text-slate-400 text-sm">
                            {prize.drawn}/{prize.total}
                          </Text>
                        </View>
                        {/* 进度条 */}
                        <View className="h-1 bg-slate-700 rounded-full overflow-hidden">
                          <View 
                            className="h-full rounded-full transition-all duration-300"
                            style={{ 
                              width: `${prize.total > 0 ? (prize.drawn / prize.total) * 100 : 0}%`,
                              backgroundColor: getPrizeColor(index)
                            }}
                          />
                        </View>
                      </View>
                    ))}
                  </CardContent>
                </Card>
              </View>
            )}

            {/* 提示信息 */}
            {eligibleParticipants.length === 0 && totalParticipants > 0 && (
              <View className="mt-4 px-4 py-2 bg-rose-500 rounded-lg opacity-80">
                <Text className="block text-white text-sm text-center">
                  所有人已中奖，可重置抽奖或导入更多人员
                </Text>
              </View>
            )}
          </View>

          {/* 功能按钮区 */}
          <View className="mb-3">
            <View className="flex gap-3">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 bg-slate-800 border-slate-600 text-slate-300"
                onClick={() => setShowResetDialog(true)}
              >
                <RotateCcw size={16} color="#9CA3AF" />
                <Text className="ml-1 text-sm">重置</Text>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 bg-slate-800 border-slate-600 text-slate-300"
                onClick={handleExport}
                disabled={totalWinners === 0}
              >
                <Download size={16} color="#9CA3AF" />
                <Text className="ml-1 text-sm">导出</Text>
              </Button>
            </View>
          </View>

          {/* 底部导航 */}
          <View className="pb-8 md:pb-12">
            <View className="flex gap-3">
              <Button
                variant="outline"
                size="sm"
                className="flex-1 bg-slate-800 border-slate-700 text-slate-300"
                onClick={goToParticipants}
              >
                <Users size={16} color="#9CA3AF" />
                <Text className="ml-1 text-sm">人员管理</Text>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 bg-slate-800 border-slate-700 text-slate-300"
                onClick={goToSettings}
              >
                <Settings size={16} color="#D4A849" />
                <Text className="ml-1 text-sm">奖项设置</Text>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="flex-1 bg-slate-800 border-slate-700 text-slate-300"
                onClick={goToWinners}
              >
                <Trophy size={16} color="#D4A849" />
                <Text className="ml-1 text-sm">中奖名单</Text>
              </Button>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* 中奖弹窗 */}
      <Dialog open={showWinnerDialog} onOpenChange={setShowWinnerDialog}>
        <DialogContent className="bg-slate-800 border-amber-500">
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-center text-xl">
              🎉 恭喜中奖！
            </DialogTitle>
          </DialogHeader>
          <View className="py-6">
            <View className="text-center">
              <Text className="block text-slate-100 text-3xl font-bold mb-2">
                {currentWinner?.name}
              </Text>
              <Text className="block text-slate-400 text-base">
                工号：{currentWinner?.employeeId}
              </Text>
              <Text className="block text-slate-400 text-base">
                部门：{currentWinner?.department}
              </Text>
            </View>
            <View className="mt-6 px-4 py-3 bg-amber-500 rounded-xl border border-amber-400">
              <Text className="block text-amber-400 text-center text-lg font-bold">
                {currentWinner?.prizeName || '幸运大奖'}
              </Text>
            </View>
          </View>
          <View className="flex justify-center pb-4">
            <Button
              className="bg-amber-500 text-slate-900 px-8"
              onClick={() => setShowWinnerDialog(false)}
            >
              <Text>确认</Text>
            </Button>
          </View>
        </DialogContent>
      </Dialog>

      {/* 批量中奖弹窗 */}
      <Dialog open={showBatchDialog} onOpenChange={setShowBatchDialog}>
        <DialogContent className="bg-slate-800 border-amber-500">
          <DialogHeader>
            <DialogTitle className="text-amber-400 text-center text-xl">
              🎉 恭喜 {batchWinners.length} 位中奖！
            </DialogTitle>
          </DialogHeader>
          <View className="py-4 max-h-60 overflow-y-auto">
            {batchWinners.map((winner, index) => (
              <View key={winner.id} className="px-4 py-2 border-b border-slate-700 last:border-0">
                <View className="flex items-center justify-between">
                  <View>
                    <Text className="block text-slate-100 font-bold">{index + 1}. {winner.name}</Text>
                    <Text className="block text-slate-400 text-sm">{winner.department}</Text>
                  </View>
                  <View className="px-2 py-1 bg-amber-500 rounded">
                    <Text className="block text-slate-900 text-sm font-bold">{winner.prizeName}</Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
          <View className="flex justify-center pb-4">
            <Button
              className="bg-amber-500 text-slate-900 px-8"
              onClick={() => setShowBatchDialog(false)}
            >
              <Text>确认</Text>
            </Button>
          </View>
        </DialogContent>
      </Dialog>

      {/* 重置确认弹窗 */}
      <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <DialogContent className="bg-slate-800 border-slate-700">
          <DialogHeader>
            <DialogTitle className="text-slate-100 text-center text-lg">
              确认重置抽奖？
            </DialogTitle>
          </DialogHeader>
          <View className="py-4">
            <Text className="block text-slate-400 text-center">
              重置后，所有中奖记录将被清空，{'\n'}
              所有人员可重新参与抽奖。
            </Text>
          </View>
          <View className="flex gap-3 pb-4">
            <Button
              variant="outline"
              className="flex-1 border-slate-600 text-slate-300"
              onClick={() => setShowResetDialog(false)}
            >
              <Text>取消</Text>
            </Button>
            <Button
              className="flex-1 bg-rose-500 text-white"
              onClick={handleReset}
            >
              <Text>确认重置</Text>
            </Button>
          </View>
        </DialogContent>
      </Dialog>
    </View>
  )
}

export default IndexPage
