export default defineAppConfig({
  pages: [
    'pages/index/index',
    'pages/participants/index',
    'pages/winners/index',
    'pages/settings/index'
  ],
  window: {
    backgroundTextStyle: 'dark',
    navigationBarBackgroundColor: '#1A1A2E',
    navigationBarTitleText: '抽奖',
    navigationBarTextStyle: 'white',
    backgroundColor: '#1A1A2E'
  }
})
